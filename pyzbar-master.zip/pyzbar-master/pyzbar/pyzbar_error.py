class PyZbarError(Exception):
    pass
